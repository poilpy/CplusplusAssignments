#include "human.h"

namespace cs_creature
{
human::human()
{

}





human::human(int newStrength, int newHitpoints)
:
    creature(newStrength, newHitpoints)
    {

    }





string human::getSpecies()
{
    return "human";
}





int human::getDamage()
{
    int damage;

    damage = creature::getDamage();

    cout << "The " << getSpecies() << " attacks for " << damage << " points!" << endl;

    return damage;
}
}
